#include <stdio.h>

//Can xay dung cac ham cho mot mang nguyen co n phan tu voi cac yeu cau sau:
//a. Ham nhap mang: de nhap cac phan tu cua mang tu nguoi dung.
//b. Ham xuat mang: de in ra cac phan tu cua mang.
//c. Ham tinh tong cac phan tu co gia tri chan.
//d. Ham dem co bao nhieu phan tu co gia tri le tren mang.
//Viet ham chinh co su dung tat ca cac ham tren.

int i;
 
void nhapMang(int arr[], int n) {
    printf("Nhap cac phan tu cua mang:\n");
    for (i = 0; i < n; ++i) {
        printf("arr[%d] = ", i);
        scanf("%d", &arr[i]);
    }
}


void xuatMang(int arr[], int n) {
    printf("Cac phan tu cua mang la:\n");
    for (i = 0; i < n; ++i) {
        printf("%d ", arr[i]);
    }
    printf("\n");
}

int tinhTongChan(int arr[], int n) {
    int tongChan = 0;
    for (i = 0; i < n; ++i) {
        if (arr[i] % 2 == 0) {
            tongChan += arr[i];
        }
    }
    return tongChan;
}

int demLe(int arr[], int n) {
    int dem = 0;
    for (i = 0; i < n; ++i) {
        if (arr[i] % 2 != 0) {
            dem++;
        }
    }
    return dem;
}

int main() {
    int n;
    printf("Nhap so luong phan tu cua mang: ");
    scanf("%d", &n);

    int arr[n];

    nhapMang(arr, n);

    xuatMang(arr, n);

    int tongChan = tinhTongChan(arr, n);
    printf("Tong cac phan tu co gia tri chan la: %d\n", tongChan);

    int soLuongLe = demLe(arr, n);
    printf("Co %d phan tu co gia tri le trong mang.\n", soLuongLe);

    return 0;
}

