#include <stdio.h>

//Can xay dung cac ham cho mot mang nguyen co n phan tu voi cac yeu cau sau:
//a. Ham nhap mang
//b. Ham tong 2 mang co cung n phan tu? 
//c. Gia su ta su dung 2 mang lan luot co n va m phan tu de bieu dien 2 tap hop. 
//Viet ham giao cua hai tap hop?
//(Lam them: d. Tuong tu cau c, viet ham hop?)
//Viet ham chinh co su dung cac ham tren.

int i, j; 
void nhap_mang(int arr[], int n) {
    for (i = 0; i < n; ++i) {
        printf("Nhap phan tu thu %d: ", i + 1);
        scanf("%d", &arr[i]);
    }
}

void tong_hai_mang(const int arr1[], const int arr2[], int n, int result[]) {
    for (i = 0; i < n; ++i) {
        result[i] = arr1[i] + arr2[i];
    }
}

void giao_hai_tap_hop(const int arr1[], const int arr2[], int n, int result[], int *size) {
    *size = 0;
    for (i = 0; i < n; ++i) {
        for (j = 0; j < n; ++j) {
            if (arr1[i] == arr2[j]) {
                result[(*size)++] = arr1[i];
                break;
            }
        }
    }
}

void hop_hai_tap_hop(const int arr1[], const int arr2[], int n, int result[], int *size) {
    *size = 0;
    for (i = 0; i < n; ++i) {
        result[(*size)++] = arr1[i];
    }
    for (i = 0; i < n; ++i) {
        int found = 0;
        for (j = 0; j < *size; ++j) {
            if (arr2[i] == result[j]) {
                found = 1;
                break;
            }
        }
        if (!found) {
            result[(*size)++] = arr2[i];
        }
    }
}

int main() {
    int n;
    printf("Nhap so phan tu cua mang: ");
    scanf("%d", &n);

    int arr1[n], arr2[n], tong[n], giao[n * 2], hop[n * 2];
    int size_giao, size_hop;

    printf("Nhap mang thu nhat:\n");
    nhap_mang(arr1, n);

    printf("Nhap mang thu hai:\n");
    nhap_mang(arr2, n);

    tong_hai_mang(arr1, arr2, n, tong);
    printf("Tong hai mang: ");
    for (i = 0; i < n; ++i) {
        printf("%d ", tong[i]);
    }
    printf("\n");

    giao_hai_tap_hop(arr1, arr2, n, giao, &size_giao);
    printf("Tap hop giao: ");
    for (i = 0; i < size_giao; ++i) {
        printf("%d ", giao[i]);
    }
    printf("\n");

    hop_hai_tap_hop(arr1, arr2, n, hop, &size_hop);
    printf("Tap hop hop: ");
    for (i = 0; i < size_hop; ++i) {
        printf("%d ", hop[i]);
    }
    printf("\n");

    return 0;
}

