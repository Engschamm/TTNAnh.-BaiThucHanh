#include <stdio.h>
#include <math.h>
int main(int argc, const char * argv[]) {
//    Vi?t ch��ng tr?nh t�nh S = 1 + 1/x + 2/x^2 + 3/x^3 + � + n/x^n
    int n;
    float sum = 0;
    float x;
    
	printf("nhap n: ");
    scanf("%d", &n);
    
	printf("Nhap x: ");
    scanf("%f", &x);
    
    int i; 
    for (i = 1; i <= n; i++) {
    	sum += i / pow(x, i);
    }

    printf("T?ng S = 1 + 1/x + 2/x^2 + ... + n/x^n = %.2f\n", sum);
    return 0;
}
