#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	//viet chuong trinh nhap diem toan li hoa. tong >=15 , all tr�n 4 thi dau. all tren 5 thi in" hoc deu cac mon".
	//nglai "hoc khong deu cac mon"
	//truong hop con lai " thi hong" 
	
	float toan, ly, hoa;
	printf("nhap diem toan, ly, hoa: \n");
	scanf("%f %f %f", &toan, &ly, &hoa);
	
	float Sum = toan + ly + hoa;
	
	if (Sum >= 15 && toan >= 4 && ly >= 4 && hoa >= 4) {
        printf("Dau\n");

        if (toan > 5 && ly > 5 && hoa > 5) {
            printf("Hoc deu cac mon\n");
        } else {
            printf("Hoc chua deu cac mon\n");
        }
    } else {
        printf("Thi hong\n");
    }
	return 0;
}
