#include <stdio.h>
//. Vi?t h�m t�nh  1 + 2^2 + 3^3 + � + n^n

int sumOfSeries(int n) {
    int sum = 0;
    int i; 
    for (i = 1; i <= n; i++) {
        int term = 1;
        int j; 
        for (j = 1; j <= i; j++) {
            term *= j;
        }
        sum += term;
    }
    return sum;
}

int main() {
    int n;
    printf("Nhap so nguyen duong: ");
    scanf("%d", &n);
    int result = sumOfSeries(n);
    printf("Tong la: %d", result);
    return 0;
}
