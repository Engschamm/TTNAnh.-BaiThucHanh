#include <stdio.h>
#include <stdlib.h>
#include <math.h> 

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	//viet chuong trinh nhap vao 2 canh cua hinh chu nhat tinh chu vi va dien tich cua hinh chu nhat nay
	
	float a, b, p, s;
	printf("nhap a va b: ");
	scanf("%f %f", &a, &b);
	s = a * b;
	p = 2 * (a * b);
	printf("chu vi cua hinh chu nhat: %.f\n", p);
	printf("dien tich cua hinh chu nhat: %.f\n", s);
	return 0;
}
