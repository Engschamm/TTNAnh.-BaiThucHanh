#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	//viet chuong trinh tinh tong S = 1 + 2 + ... + n
	int i, n;
	long int s;
	
	printf("nhap n: ");
	scanf("%d", &n);
	
	s = 0;
	for(i = 0; i <= n; i++){
		s += i;
	}
	
	printf("tong cua 1 + ... + %d = %ld\n", n , s);
	return 0;
}
