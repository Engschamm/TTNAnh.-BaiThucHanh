#include <stdio.h>
#include <stdlib.h>
#include<math.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	//viet chuong trinh tinh can bac k cua mot so x nhap vao tu ban phim
	
int k;
float x, c;
printf("nhap x: ");
scanf("%f", &x);
printf("nhap k: ");
scanf("%d", &k);
c = exp(log(x)/k);
printf("Can bac %d  cua  %5.2f =%5.2f",k, x, c);
	return 0;
}
