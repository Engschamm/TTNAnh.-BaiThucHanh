#include <stdio.h>
#include <stdlib.h>
#include <math.h> 

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	//nhap vao ban kinh cua hinh tron tinh chu vi va dien tich cua hinh tron nay
	
float r, c, s;

printf("nhap ban kinh: ");
scanf("%f", &r);

c = 2 * M_PI * r; 
s = M_PI * r * r;

printf("chu vi cua hinh tron la: %.f\n", c);

printf("dien tich cua hinh tron la: %.f\n", s);

return 0;
}
