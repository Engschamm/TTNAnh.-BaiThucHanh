#include <stdio.h>
#include <stdlib.h>

// Viet ham tinh tong 1 + 2 + � + n
int calculateSum(int n);

int main() {
  int n;
  printf("Nhap so n: ");
  scanf("%d", &n);

  int total = calculateSum(n);
  printf("Tong 1 + 2 + ... + %d = %d\n", n, total);

  return 0;
}

int calculateSum(int n) {
  int i, sum = 0;
  for (i = 1; i <= n; i++) {
    sum += i;
  }
  return sum;
}

