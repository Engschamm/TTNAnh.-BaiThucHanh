#include <stdio.h>
//Vi?t h�m t�nh  1 + 2^n + 3^n + � + n^n 
int tinh_tong(int n) {
int S = 0;
int i; 
  for (i = 1; i <= n; i++) {
    int x = i * i;

    S += x;
  }


  return S;
}

int main() {
  int n;
  printf("Nhap so tu nhien n: ");
  scanf("%d", &n);

  int S = tinh_tong(n);

  printf("T?ng S = 1 + 2^n + 3^n + ... + n^n = %d\n", S);
    return 0;
}
