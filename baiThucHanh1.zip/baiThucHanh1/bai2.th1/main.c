#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	//nhap vao 2 so nguyen sau do tinh tong hieu tich thuong 
	
	int a, b;
	printf("nhap vao so nguyen a va b: \n");
	scanf("%d %d", &a, &b);
	printf("%d + %d = %d, %d - %d = %d\n", a, b, a + b, a, b, a - b);
	printf("%d * %d = %d, %d / %d = %d\n", a, b, a * b, a, b, a / b);

	return 0;
}
