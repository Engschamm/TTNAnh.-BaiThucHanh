#include <stdio.h>

int main(int argc, const char * argv[]) {
//    Viet chuong trinh tinh S = 1 + 1/x^1 + 1/x^2 + � + 1/x^n
    int n;
    float sum = 0;
    
    printf("Nhap n: ");
    scanf("%d", &n);
    
    int i; 
	for (i = 1; i <= n; i++) {
    sum += 1.0f / i;
    }
    
    printf("Tong S = 1 + 1/x^1 + 1/x^2 + � + 1/x^n = %.2f\n", sum);
    
    return 0;
}
