#include <stdio.h>
#include <math.h>

int main(int argc, const char * argv[]) {
//    Vi?t ch��ng tr?nh nh?p v�o 3 c?nh c?a m?t tam gi�c (gi? s? s? li?u nh?p v�o lu�n �?m b?o t?o th�nh tam gi�c). H?y t�nh chu vi v� di?n t�ch c?a tam gi�c n�y.

    float a, b, c;
    
    printf("nhap a, b, c: ");
    scanf("%f %f %f", &a, &b, &c); 
    
	if (a + b <= c || a + c <= b || b + c <= a) {
    	printf("Ba c?nh kh�ng t?o th�nh tam gi�c\n");
    	return 0;
    }

      float perimeter = a + b + c;

      float s = (a + b + c) / 2;
      float area = sqrt(s * (s - a) * (s - b) * (s - c));

      printf("Chu vi c?a tam gi�c l� %.2f\n", perimeter);
      printf("Di?n t�ch c?a tam gi�c l� %.2f\n", area);
    
    return 0;
}
