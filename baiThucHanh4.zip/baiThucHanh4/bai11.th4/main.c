#include <stdio.h>
#include <math.h>


int isPrime(int num) {
    if (num <= 1) {
        return 0;
    }
    int i; 
    for (i = 2; i <= sqrt(num); i++) {
        if (num % i == 0) {
            return 0; 
        }
    }
    return 1;
}


void printPrimesLessThan(int n) {
	int i; 
    for (i = 2; i < n; i++) {
        if (isPrime(i)) {
            printf("%d ", i);
        }
    }
}

int main() {
    int N;
    printf("Nhap N: ");
    scanf("%d", &N);
    printPrimesLessThan(N);
    return 0;
}

