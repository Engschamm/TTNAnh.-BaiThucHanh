#include <stdio.h>

//Bai 2. Dinh nghia kieu du lieu phan so. Hay viet cac ham: 
//a. Nhap n phan so 
//b. Tim phan so lon nhat trong n phan so nay 
//c. Tinh tong cac phan so 
//Viet ham chinh co su dung cac ham tren.

struct PhanSo {
    int tu, mau;
};

void NhapNPhanSo(PhanSo ds[], int n) {
    for (int i = 0; i < n; i++) {
        printf("Nhap phan so thu %d:\n", i + 1);
        printf("Tu so: ");
        scanf("%d", &ds[i].tu);
        printf("Mau so: ");
        scanf("%d", &ds[i].mau);

        int ucln = 1; 
        int a = ds[i].tu, b = ds[i].mau;
        while (b != 0) {
            int r = a % b;
            a = b;
            b = r;
        }
        ucln = a;

        ds[i].tu = ds[i].tu / ucln;
        ds[i].mau = ds[i].mau / ucln;
    }
}

PhanSo TimPhanSoLonNhat(PhanSo ds[], int n) {
    PhanSo maxPhanSo = ds[0];
    for (int i = 1; i < n; i++) {
        int lcm = maxPhanSo.mau;
        int a = maxPhanSo.tu, b = ds[i].tu;
        while (b != 0) {
            int r = a % b;
            a = b;
            b = r;
        }
        int gcd = a;
        int ucln = (maxPhanSo.mau * ds[i].mau) / gcd;

        int tuSo1 = maxPhanSo.tu * (ucln / maxPhanSo.mau);
        int tuSo2 = ds[i].tu * (ucln / ds[i].mau);

        if (tuSo1 < tuSo2) {
            maxPhanSo = ds[i];
        }
    }

    return maxPhanSo;
}

PhanSo TinhTongNPhanSo(PhanSo ds[], int n) {
    PhanSo tong = ds[0];
    for (int i = 1; i < n; i++) {
        int lcm = tong.mau;
        int a = tong.tu, b = ds[i].tu;
        while (b != 0) {
            int r = a % b;
            a = b;
            b = r;
        }
        int gcd = a;
        int ucln = (tong.mau * ds[i].mau) / gcd;

        tong.tu = tong.tu * (ucln / tong.mau) + ds[i].tu * (ucln / ds[i].mau);
        tong.mau = ucln;

        int c = a;
        tong.tu = tong.tu / c;
        tong.mau = tong.mau / c;
    }

    return tong;
}

int main() {
    int n;
    printf("Nhap so luong phan so: ");
    scanf("%d", &n);

    PhanSo dsPhanSo[n];

    NhapNPhanSo(dsPhanSo, n);

    PhanSo maxPhanSo = TimPhanSoLonNhat(dsPhanSo, n);
    printf("Phan so lon nhat:\n");
    printf("Tu so: %d\n", maxPhanSo.tu);
    printf("Mau so: %d\n", maxPhanSo.mau);

    PhanSo tongPhanSo = TinhTongNPhanSo(dsPhanSo, n);
    printf("Tong cac phan so:\n");
    printf("Tu so: %d\n", tongPhanSo.tu);
    printf("Mau so: %d\n", tongPhanSo.mau);

    return 0;
}

