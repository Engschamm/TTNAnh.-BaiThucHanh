#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	//viet chuong trinh tinh tong s = 1 + 1/2 + ... + 1/n
	
	int i, n;
	float s;
	
	printf("nhap n: ");
	scanf("%d", &n);
	
	s = 0;
	for(i = 1; i <= n; i++){
		s += 1.0/i;
		}
		
	printf("tong cua 1 + ... + 1/%d = %f\n", n , s);
	return 0;
}
