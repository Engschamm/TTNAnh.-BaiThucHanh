#include <stdio.h>

//Can xay dung cac ham cho mot mang nguyen co n phan tu voi cac yeu cau sau:
//a. Ham nhap mang.
//b. Ham kiem tra mang co phai la mang chua cac phan tu duong khong?
//c. Ham kiem tra mang co doi xung khong?
//d. Ham kiem tra mang co tao thanh day tang dan khong?
//(Lam them:
//e. Ham kiem tra mang co tao thanh cap so cong khong?
//f. Ham kiem tra mang co tao thanh mang rang cua khong?
//g. Ham kiem tra co ton tai phan tu chua gia tri X tren mang?)
//Viet ham chinh co su dung cac ham tren.

int i; 

void nhapMang(int arr[], int n) {
    printf("Nhap cac phan tu cua mang:\n");
    for (i = 0; i < n; ++i) {
        printf("arr[%d] = ", i);
        scanf("%d", &arr[i]);
    }
}


int kiemTraDuong(int arr[], int n) {
    for (i = 0; i < n; ++i) {
        if (arr[i] <= 0) {
            return 0; 
        }
    }
    return 1;
}


int kiemTraDoiXung(int arr[], int n) {
    for (i = 0; i < n/2; ++i) {
        if (arr[i] != arr[n-1-i]) {
            return 0; 
        }
    }
    return 1; 
}


int kiemTraTangDan(int arr[], int n) {
    for (i = 1; i < n; ++i) {
        if (arr[i] < arr[i-1]) {
            return 0;
        }
    }
    return 1; 
}


int kiemTraCapSoCong(int arr[], int n) {
    if (n < 3) {
        return 1; 
    }

    int chenhLech = arr[1] - arr[0];
    for (i = 2; i < n; ++i) {
        if (arr[i] - arr[i-1] != chenhLech) {
            return 0; 
        }
    }
    return 1; 
}


int kiemTraRangCua(int arr[], int n) {
    for (i = 1; i < n-1; ++i) {
        if ((arr[i] > arr[i-1] && arr[i] > arr[i+1]) || (arr[i] < arr[i-1] && arr[i] < arr[i+1])) {
            continue;
        } else {
            return 0; 
        }
    }
    return 1; 
}


int kiemTraTonTaiX(int arr[], int n, int X) {
    for (i = 0; i < n; ++i) {
        if (arr[i] == X) {
            return 1; 
        }
    }
    return 0; 
}


int main() {
    int n;
    printf("Nhap so luong phan tu cua mang: ");
    scanf("%d", &n);

    int arr[n];

    nhapMang(arr, n);

    if (kiemTraDuong(arr, n)) {
        printf("Mang chua cac phan tu duong.\n");
    } else {
        printf("Mang khong chua cac phan tu duong.\n");
    }

    if (kiemTraDoiXung(arr, n)) {
        printf("Mang la mang doi xung.\n");
    } else {
        printf("Mang khong la mang doi xung.\n");
    }

    if (kiemTraTangDan(arr, n)) {
        printf("Mang la mang tang dan.\n");
    } else {
        printf("Mang khong la mang tang dan.\n");
    }

    if (kiemTraCapSoCong(arr, n)) {
        printf("Mang la mang cap so cong.\n");
    } else {
        printf("Mang khong la mang cap so cong.\n");
    }

    if (kiemTraRangCua(arr, n)) {
        printf("Mang la mang rang cua.\n");
    } else {
        printf("Mang khong la mang rang cua.\n");
    }

    int X;
    printf("Nhap gia tri X can kiem tra: ");
    scanf("%d", &X);

    if (kiemTraTonTaiX(arr, n, X)) {
        printf("Ton tai phan tu chua gia tri %d tren mang.\n", X);
    } else {
        printf("Khong ton tai phan tu chua gia tri %d tren mang.\n", X);
    }

    return 0;
}

