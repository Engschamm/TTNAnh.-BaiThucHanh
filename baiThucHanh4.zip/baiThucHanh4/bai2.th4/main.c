#include <stdio.h>

//Viet ham t�nh  1*2* � *n.
int sum(int n) {
    int i, sum = 0;
    for (i = 1; i <= n; i++) {
        sum += i;
    }
    return sum;
}
int main() {
    int n, result;
    printf("nhap so: ");
    scanf("%d", &n);
    result = sum(n);
    printf("tong : %d", result);
    return 0;
}
