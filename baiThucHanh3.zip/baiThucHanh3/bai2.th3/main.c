#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	//viet chuong trinh tinh tich p = 1 * 2 * ... * n;
	
	int i, n;
	long int p;
	
	printf("nhap n: ");
	scanf("%d", &n);
	
	p = 1;
	for(i = 1; i <= n; i++){
		p *= i;
	}
	
	printf("tich cua 1 * ... * %d = %d\n", n , p);
return 0;
}
