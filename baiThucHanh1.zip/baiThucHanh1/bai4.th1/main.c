#include <stdio.h>
#include <stdlib.h>
#include<math.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	//viet chuong trinh tinh can bac 2 cua mot so x nhap vao tu ban phim
	
	float x, c;
	printf("nhap vao so x: ");
	scanf("%f", &x);
	c = sqrt(x);
	printf("Can bac hai cua %5.2f = =%5.2f",x, c);
	return 0;
}
