#include <stdio.h>
//Vi?t h�m t?m USCNL v� h�m t?m BSCNN c?a 2 s? nguy�n a, b
int USCLN(int a, int b) {
  while (b != 0) {
    int tam = b;
    b = a % b;
    a = tam;
  }
  return a;
}

int BSCNN(int a, int b) {
  return a * b / USCLN(a, b);
}

int main() {
  int a, b;
  printf("Nhap hai so nguyen a, b: ");
  scanf("%d %d", &a, &b);

  int uscln = USCLN(a, b);
  int bscnn = BSCNN(a, b);

  printf("USCLN(%d, %d) = %d\n", a, b, uscln);
  printf("BSCNN(%d, %d) = %d\n", a, b, bscnn);
    return 0;
}
