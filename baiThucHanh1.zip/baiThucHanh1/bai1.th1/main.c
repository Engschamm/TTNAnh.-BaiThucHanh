#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	//bai 1 in ra cac dong 
	
	int i;
	printf("chao cac ban");
	scanf("%d");
	printf("chao   cac   ban");
	scanf("%d");
	printf("chao\n");
	printf("cac\n");
	printf("ban\n");
	scanf("%d %d %d");
	return 0;
}
