#include <stdio.h>

//Bai 5 Can xay dung cac ham cho mot ma tran co NxM phan tu kieu nguyen voi cac yeu cau sau 
//a Ham nhap ma tran 
//b Ham xuat ma tran 
//c Ham tong 2 ma tran co cung kich thuoc NxM 
//d Ham tinh tich 2 ma tran kich thuoc lan luot la NxK va KxM 
//Viet ham chinh co su dung cac ham tren.

int i, j; 
void nhapMaTran(int a[][100], int row, int col) {
    printf("Nhap ma tran:\n");
    for (i = 0; i < row; i++) {
        for (j = 0; j < col; j++) {
            printf("a[%d][%d]: ", i, j);
            scanf("%d", &a[i][j]);
        }
    }
}

void xuatMaTran(int a[][100], int row, int col) {
    printf("Ma tran:\n");
    for (i = 0; i < row; i++) {
        for (j = 0; j < col; j++) {
            printf("%d\t", a[i][j]);
        }
        printf("\n");
    }
}

void tongMaTran(int a[][100], int b[][100], int c[][100], int row, int col) {
    for (i = 0; i < row; i++) {
        for (j = 0; j < col; j++) {
            c[i][j] = a[i][j] + b[i][j];
        }
    }
}

void tichMaTran(int a[][100], int b[][100], int c[][100], int rowA, int colA, int colB) {
    for (i = 0; i < rowA; i++) {
        for (j = 0; j < colB; j++) {
            c[i][j] = 0;
            int k; 
            for (k = 0; k < colA; k++) {
                c[i][j] += a[i][k] * b[k][j];
            }
        }
    }
}

int main() {
    int a[100][100], b[100][100], c[100][100];
    int row, col, rowA, colA, rowB, colB;

    printf("Nhap so hang cua ma tran A: ");
    scanf("%d", &rowA);
    printf("Nhap so cot cua ma tran A: ");
    scanf("%d", &colA);

    nhapMaTran(a, rowA, colA);

    xuatMaTran(a, rowA, colA);

    printf("Nhap so hang cua ma tran B: ");
    scanf("%d", &rowB);
    printf("Nhap so cot cua ma tran B: ");
    scanf("%d", &colB);

    nhapMaTran(b, rowB, colB);

    xuatMaTran(b, rowB, colB);

    if (rowA == rowB && colA == colB) {
   
        tongMaTran(a, b, c, rowA, colA);

        printf("Tong ma tran A va B:\n");
        xuatMaTran(c, rowA, colA);
    } else if (colA == rowB) {

        tichMaTran(a, b, c, rowA, colA, colB);

        printf("Tich ma tran A va B:\n");
        xuatMaTran(c, rowA, colB);
    } else {
        printf("Khong the tinh tong hoac tich ma tran vi kich thuoc khong hop le.\n");
    }

    return 0;
}

