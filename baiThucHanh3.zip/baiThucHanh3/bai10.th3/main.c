#include <stdio.h>

int main() {
	//viet chuong trinh xac dinh xem 1 to giay co do day 0.1mm
	//phai gap to giay bao nhieu lan den dat do day 1m 
	
    double Langap = 0.1;
    double Day = 0;
    
    printf("Nhap do day cua to giay (mm): ");
    scanf("%lf", &Day);

    while (Day < 1000) {
        Langap++;  
        Day = Day * 2;  
    }

    printf("so lan gap can thiet la: %.0lf\n", Langap);

    return 0;
}

