#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	
// Viet chuong trinh tinh tien dien gom cac khoang sau:
//- Tien thue bao dien ke: 1000d/thang
//- Dinh muc su dung dien cho moi ho la: 50 KW voi gia 230d/KW
//- Neu phan vuot dinh muc <= 50KW thi tinh gia 480d/KW
//- Neu 50KW < phan vuot dinh muc < 100KW thi tinh gia 700d/KW
//- Neu phan vuot dinh muc <= 100KW thi tinh gia 900d/KW
//Chi so moi va cu duoc nhap vao tu ban phim.

	int chiSoCu, chiSoMoi;
    float tienThueBao, dinhMuc, giaDinhMuc, giaVuot1, giaVuot2, tienDien;

    printf("Nhap chi so cu: ");
    scanf("%d", &chiSoCu);

    printf("Nhap chi so moi: ");
    scanf("%d", &chiSoMoi);

    dinhMuc = 50; 
    giaDinhMuc = 230; 
    giaVuot1 = 480; 
    giaVuot2 = 700; 

    float soKW = chiSoMoi - chiSoCu;

    if (soKW <= dinhMuc) {
        tienDien = tienThueBao + soKW * giaDinhMuc;
    } else {
        if (soKW <= 2 * dinhMuc) {
            tienDien = tienThueBao + dinhMuc * giaDinhMuc + (soKW - dinhMuc) * giaVuot1;
        } else {
            tienDien = tienThueBao + dinhMuc * giaDinhMuc + dinhMuc * giaVuot1 + (soKW - 2 * dinhMuc) * giaVuot2;
        }
    }

    printf("Tien dien la: %.2f VND\n", tienDien);
	return 0;
}
