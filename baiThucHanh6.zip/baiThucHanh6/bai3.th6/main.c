#include <stdio.h>

//Bai 3. Dinh nghia kieu du lieu so phuc. Hay viet cac ham: 
//a. Nhap 1 so phuc 
//b. Tinh tong 2 so phuc 
//c. Tinh tich hai so phuc 
//Viet ham chinh co su dung cac ham tren. 

struct Sophuc {
    float thuc, ao;
};

void Nhap(Sophuc &x) {
    printf("Nhap phan thuc: ");
    scanf("%f", &x.thuc);
    printf("Nhap phan ao: ");
    scanf("%f", &x.ao);
}

Sophuc TinhTong(Sophuc x, Sophuc y) {
    Sophuc tong;
    tong.thuc = x.thuc + y.thuc;
    tong.ao = x.ao + y.ao;
    return tong;
}

Sophuc TinhTich(Sophuc x, Sophuc y) {
    Sophuc tich;
    tich.thuc = x.thuc * y.thuc - x.ao * y.ao;
    tich.ao = x.thuc * y.ao + x.ao * y.thuc;
    return tich;
}

int main() {
    Sophuc soPhuc1, soPhuc2, tong, tich;

    printf("Nhap so phuc thu nhat:\n");
    Nhap(soPhuc1);

    printf("Nhap so phuc thu hai:\n");
    Nhap(soPhuc2);

    tong = TinhTong(soPhuc1, soPhuc2);
    printf("Tong hai so phuc:\n");
    printf("%.2f + %.2fi\n", tong.thuc, tong.ao);

    tich = TinhTich(soPhuc1, soPhuc2);
    printf("Tich hai so phuc:\n");
    printf("%.2f + %.2fi\n", tich.thuc, tich.ao);

    return 0;
}

