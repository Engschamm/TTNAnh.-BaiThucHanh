#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	//nhap vao 3 so nguyen, tim gia tri cuc dai
	int a, b, c;
	
	printf("nhap vao 3 so a, b, c: ");
	scanf("%d %d %d", &a, &b, &c); 
	
	if (a >= b && a >= c) {
        printf("Gia tri lon nhat la: %d\n", a);
   } else if (b >= a && b >= c) {
        printf("Gia tri lon nhat la: %d\n", b);
   } else {
        printf("Gia tri lon nhat la: %d\n", c);
   }
	return 0;
}
