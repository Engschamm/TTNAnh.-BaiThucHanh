#include <stdio.h>
#include <math.h>

int main(int argc, const char * argv[]) {
// viet chuong trinh tinh sin, cos cua mot so nhap vao tu ban phim, voi x la so do can tinh 
    

    float x;
    

    printf("Nhap so do: ");
    scanf("%f", &x);
    
    float sinx = sin(x * M_PI / 180);
    float cosx = cos(x * M_PI / 180);
    
    printf("sin(%1.f) = %2.f\n", x, sinx);
    printf("cos(%1.f) = %2.f\n", x, cosx);
    
    return 0;
}
