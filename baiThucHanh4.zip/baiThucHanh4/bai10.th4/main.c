#include <stdio.h>
//Vi?t h�m ki?m tra s? nguy�n x c� ph?i l� nguy�n t? kh�ng?
int isPrime(int x) {
  if (x < 2) {
    return 0;
  }
int i; 
  for (i = 2; i * i <= x; i++) {
    if (x % i == 0) {
      return 0;
    }
  }

  return 1;
}

int main() {
  int x;

  printf("Nhap so nguyen x: ");
  scanf("%d", &x);

  if (isPrime(x)) {
    printf("%d la so nguyen to.\n", x);
  } else {
    printf("%d khong phai so nguyen to.\n", x);
  }
    return 0;
}
