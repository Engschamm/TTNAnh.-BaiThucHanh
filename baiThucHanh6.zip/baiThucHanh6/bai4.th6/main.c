#include <stdio.h>

struct Time {
    int gio, phut, giay;
};

void Nhap(Time &x) {
    printf("Nhap gio: ");
    scanf("%d", &x.gio);
    printf("Nhap phut: ");
    scanf("%d", &x.phut);
    printf("Nhap giay: ");
    scanf("%d", &x.giay);
}

void TangThoiGian(Time &x, int x) {
    int tongGiay = x.gio * 3600 + x.phut * 60 + x.giay;
    tongGiay += x;
    
    x.gio = tongGiay / 3600;
    x.phut = (tongGiay % 3600) / 60;
    x.giay = tongGiay % 60;
}

int main() {
    Time thoiGian;

    printf("Nhap thoi gian:\n");
    Nhap(thoiGian);

    printf("Thoi gian truoc khi tang: %02d:%02d:%02d\n", thoiGian.gio, thoiGian.phut, thoiGian.giay);

    int soGiayTang;
    printf("Nhap so giay muon tang: ");
    scanf("%d", &soGiayTang);

    TangThoiGian(thoiGian, soGiayTang);

    printf("Thoi gian sau khi tang: %02d:%02d:%02d\n", thoiGian.gio, thoiGian.phut, thoiGian.giay);

    return 0;
}

