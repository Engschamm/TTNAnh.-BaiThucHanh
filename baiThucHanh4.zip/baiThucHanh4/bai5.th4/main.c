#include <stdio.h>
//Viet ham tinh  1! + 2! + � + n!
int factorial(int n) {
    int i;
    int result = 1;

    for (i = 1; i <= n; i++) {
        result *= i;
    }
    return result;
}

int main() {
    int n;
    printf("Enter a number: ");
    scanf("%d", &n);
    int result = factorial(n);
    printf("Factorial of %d is %d", n, result);
    return 0;
}
