#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	//viet chuong trinh tinh S = 1! + 2! + � + n!
	
	int n;
	
	printf("nhap n: ");
	scanf("%d", &n);
	
	if (n <= 0){
		printf("n phai la so nguyen duong");
		return 0;
	}
	
	long long tong = 1;
	
	int i;
	
	for (i = 2; i <= n; i++){
		tong *= i;
	
	}
	printf("Tong cua s = 1! + 2! + � + n! la:  %lld\n", tong);
	return 0;
}
