#include <stdio.h>

int main(int argc, const char * argv[]) {
// viet chuong trinh kiem tra so n nhap vao tu ban phim co phai la so nguyen to khong 
    int n;
    
	printf("Nhap so nguyen duong n: ");
    scanf("%d", &n);
    
	if (n <= 1) {
        printf("So %d khong phai la so nguyen to.\n", n);
    return 0;
    }
	int i; 
    for (i = 2; i * i <= n; i++) {
    	if (n % i == 0) {
          printf("So %d khong phai la so nguyen to.\n", n);
          return 0;
        }
    }
    
    printf("So %d la so nguyen to.\n", n);
    return 0;
}
