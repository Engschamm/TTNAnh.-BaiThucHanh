#include <stdio.h>
#include <math.h>
//Vi?t h�m t�nh  1 + 1/x + 2/x^2 + 3/x^3 + � + n/x^n

float tinh_tong(int n, float x) {
  float x1 = 1 - pow(1/x, n);
  float x2 = 1 - 1/x;
  float S = x1 / x2;

  return S;
}

int main() {
  int n;
  printf("Nhap so tu nhien n: ");
  scanf("%d", &n);

  float x;
  printf("Nhap so thuc x: ");
  scanf("%f", &x);

  float S = tinh_tong(n, x);

  printf("Tong S = 1 + 1/x + 2/x^2 + ... + n/x^n = %.2f\n", S);
    return 0;
}
