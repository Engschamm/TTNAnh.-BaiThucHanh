#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	//viet chuong trinh tinh S = 1 + 2^2 + 3^3 + � + n^n
int n;

printf("nhap n: ");
scanf("%d", &n);

long long int sum = 0;

int i;

for(i = 0; i <= n; i++){
	long long int term = 1;
	
	int j;
        for (j = 1; j <= i; j++) {
            term *= i;
        }
        
        sum += term;
    }

    printf("Tong S = 1 + 2^2 + 3^3 + ... + %d^%d = %lld\n", n, n, sum);
	return 0;
}
