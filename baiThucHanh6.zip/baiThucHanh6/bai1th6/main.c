#include <stdio.h>

//Bai 1. Dinh nghia kieu du lieu phan so. Hay viet cac ham: 
//a. Nhap 1 phan so 
//b. Xuat 1 phan so 
//c. Tinh tong 2 phan so 
//d. Tinh tich hai phan so 
//Viet ham chinh co su dung cac ham tren.

struct PS {
    int tu, mau;
};

int USCLN(int a, int b) {
    while (b != 0) {
        int r = a % b;
        a = b;
        b = r;
    }
    return a;
}

void Nhap(PS &x) {
    printf("Tu so: ");
    scanf("%d", &x.tu);
    printf("Mau so: ");
    scanf("%d", &x.mau);

    int c = USCLN(x.tu, x.mau);
    x.tu = x.tu / c;
    x.mau = x.mau / c;
}

void Xuat(PS x) {
    printf("Gia tri phan so: %d/%d\n", x.tu, x.mau);
}

PS Tong(PS x, PS y) {
    PS t;
    t.tu = x.tu * y.mau + y.tu * x.mau;
    t.mau = x.mau * y.mau;
    
    int c = USCLN(t.tu, t.mau);
    t.tu = t.tu / c;
    t.mau = t.mau / c;

    return t;
}

PS Tich(PS x, PS y) {
    PS t;
    t.tu = x.tu * y.tu;
    t.mau = x.mau * y.mau;

    int c = USCLN(t.tu, t.mau);
    t.tu = t.tu / c;
    t.mau = t.mau / c;

    return t;
}

int main() {
    PS phanSo1, phanSo2, tong, tich;

    printf("Nhap phan so thu nhat:\n");
    Nhap(phanSo1);

    printf("Phan so thu nhat: ");
    Xuat(phanSo1);

    printf("\nNhap phan so thu hai:\n");
    Nhap(phanSo2);

    printf("Phan so thu hai: ");
    Xuat(phanSo2);

    tong = Tong(phanSo1, phanSo2);
    printf("\nTong hai phan so: ");
    Xuat(tong);

    tich = Tich(phanSo1, phanSo2);
    printf("Tich hai phan so: ");
    Xuat(tich);

    return 0;
}

