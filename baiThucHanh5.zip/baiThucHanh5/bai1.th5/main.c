#include <stdio.h>

//Nhap gia tri cho mang nguyen co n phan tu (n duoc nhap tu ban phim),
//sau do tinh tong cua cac phan tu co gia tri chan tren mang

int i; 

int tinhTongChan(int arr[], int n) {
    int tongChan = 0;
    for (i = 0; i < n; ++i) {
        if (arr[i] % 2 == 0) {
            tongChan += arr[i];
        }
    }
    return tongChan;
}

int main() {
    int n;

    printf("Nhap so luong phan tu cua mang: ");
    scanf("%d", &n);

    int arr[n];

    printf("Nhap cac phan tu cua mang:\n");
    for (i = 0; i < n; ++i) {
        printf("arr[%d] = ", i);
        scanf("%d", &arr[i]);
    }

    int tongChan = tinhTongChan(arr, n);

    printf("Tong cac phan tu co gia tri chan la: %d\n", tongChan);

    return 0;
}

