#include <stdio.h>

//Viet h�m t�nh  1/2 + 2/3 + � + (n-1)/n

float sumOfSeries(int n) {
    float sum = 0;
    int i; 
    for (i = 1; i < n; i++) {
        sum += (float)i / (float)n;
    }
    return sum;
}

int main() {
    int n;
    printf("Nhap gia tri n: ");
    scanf("%d", &n);
    float result = sumOfSeries(n);
    printf("Tong gia tri n la: %.2f", result);
    return 0;
}
